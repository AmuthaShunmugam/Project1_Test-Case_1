package com.ibm.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ibm.pages.AdminPage;
import com.ibm.utilities.ExcelUtil;
import com.ibm.utilities.PropertiesFileHandler;

public class BaseTest {
	//TestCase 1 given to check the login of admin tab and modifying the tab and its sort order
	@Test
	public void testcase1() throws IOException, InterruptedException
	{
		//To take the data given in the 'data.properties' file
		String file="./TestData/data.properties";
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data= propFileHandler.getPropertiesAsMap(file);
		String url= data.get("url");
	//To use the chrome driver and get the url, maximize window
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get(url);
	String userName = data.get("username");
	String password = data.get("password");
	//To run the xpath and method created in AdminPage.java
	AdminPage home = new AdminPage(driver);
	//To get the mail address from properties file and calling the method from Admin.java page
	home.EnetrEmailAddress(userName);Thread.sleep(3000);
	//To get the password
	home.EnetrPassword(password);Thread.sleep(3000);
	//To click on the login button
	home.ClickonLoginButton();Thread.sleep(3000);
	//To click on the Catalog button
	home.ClickonCatalogTabButton();Thread.sleep(3000);
	//To click on tab button
	home.ClickonTabButton();Thread.sleep(3000);
	//To click on Action button of the first data
	home.ClickonAction();Thread.sleep(3000);
	//To click on the edit button 
    home.ClickonEditButton();Thread.sleep(3000);
    //To edit the tab name
	home.EntertheTabName();Thread.sleep(2000);
	//To edit the sort order
	home.EnetrtheSortOrder();Thread.sleep(2000);
	//To change the status
	home.EntertheStatus();Thread.sleep(2000);
	//To click on save once edit is done 
	home.ClickonTheSaveButton();Thread.sleep(2000);
	//To verify whether after the save button it is going back and changes are implement by checking it with the first page title over there
	Assert.assertTrue(driver.findElement(By.xpath("//img[@title='EasyOrdering']")).isDisplayed());Thread.sleep(2000);
	//home.ClickonLogoutButton();
	}
	
}
